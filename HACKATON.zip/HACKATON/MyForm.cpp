#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]

int main(array<String^>^ arguments) {

	Application::SetCompatibleTextRenderingDefault(false);
	Application::EnableVisualStyles();
	HACKATON::MyForm main_form;
	Application::Run(% main_form);

}