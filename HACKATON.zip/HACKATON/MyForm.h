#pragma once

#include <fstream>
#include <msclr\marshal_cppstd.h>
#include <ctime>



namespace HACKATON {


	

	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ Category;
	protected:

	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::TextBox^ Credits;
	private: System::Windows::Forms::TextBox^ Description;


	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ Error_label;
	private: System::Windows::Forms::RichTextBox^ Statistic_label;
	private: System::Windows::Forms::Button^ Statistic_button;
	private: System::Windows::Forms::Button^ Delete_button;
	private: System::Windows::Forms::TextBox^ Find_text;

	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Button^ Find_button;
	private: System::Windows::Forms::RadioButton^ No_sort_button;
	private: System::Windows::Forms::RadioButton^ Buble_sort_button;
	private: System::Windows::Forms::RadioButton^ Quick_sort_button;
	private: System::Windows::Forms::CheckBox^ Date_sort_button;
	private: System::Windows::Forms::CheckBox^ Credits_sort_button;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^ Graph;
	private: System::Windows::Forms::CheckBox^ Sort_type;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
















	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Legend^ legend1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
			System::Windows::Forms::DataVisualization::Charting::Series^ series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			this->Category = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->Credits = (gcnew System::Windows::Forms::TextBox());
			this->Description = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Error_label = (gcnew System::Windows::Forms::Label());
			this->Statistic_label = (gcnew System::Windows::Forms::RichTextBox());
			this->Statistic_button = (gcnew System::Windows::Forms::Button());
			this->Delete_button = (gcnew System::Windows::Forms::Button());
			this->Find_text = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->Find_button = (gcnew System::Windows::Forms::Button());
			this->No_sort_button = (gcnew System::Windows::Forms::RadioButton());
			this->Buble_sort_button = (gcnew System::Windows::Forms::RadioButton());
			this->Quick_sort_button = (gcnew System::Windows::Forms::RadioButton());
			this->Date_sort_button = (gcnew System::Windows::Forms::CheckBox());
			this->Credits_sort_button = (gcnew System::Windows::Forms::CheckBox());
			this->Graph = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->Sort_type = (gcnew System::Windows::Forms::CheckBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Graph))->BeginInit();
			this->SuspendLayout();
			// 
			// Category
			// 
			this->Category->Location = System::Drawing::Point(4, 85);
			this->Category->Name = L"Category";
			this->Category->Size = System::Drawing::Size(239, 22);
			this->Category->TabIndex = 0;
			this->Category->TextChanged += gcnew System::EventHandler(this, &MyForm::Category_TextChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(53, 41);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(134, 29);
			this->label1->TabIndex = 1;
			this->label1->Text = L"���������";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Aquamarine;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button1->Location = System::Drawing::Point(41, 426);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(165, 75);
			this->button1->TabIndex = 2;
			this->button1->Text = L"����";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// Credits
			// 
			this->Credits->Location = System::Drawing::Point(6, 234);
			this->Credits->Name = L"Credits";
			this->Credits->Size = System::Drawing::Size(239, 22);
			this->Credits->TabIndex = 3;
			this->Credits->TextChanged += gcnew System::EventHandler(this, &MyForm::Credits_TextChanged);
			// 
			// Description
			// 
			this->Description->Location = System::Drawing::Point(8, 380);
			this->Description->Name = L"Description";
			this->Description->Size = System::Drawing::Size(239, 22);
			this->Description->TabIndex = 4;
			this->Description->TextChanged += gcnew System::EventHandler(this, &MyForm::Description_TextChanged);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(62, 334);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(125, 29);
			this->label2->TabIndex = 5;
			this->label2->Text = L"��������";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(69, 187);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(109, 29);
			this->label3->TabIndex = 6;
			this->label3->Text = L"�������";
			// 
			// Error_label
			// 
			this->Error_label->AutoSize = true;
			this->Error_label->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Error_label->ForeColor = System::Drawing::Color::Red;
			this->Error_label->Location = System::Drawing::Point(350, 91);
			this->Error_label->Name = L"Error_label";
			this->Error_label->Size = System::Drawing::Size(0, 29);
			this->Error_label->TabIndex = 7;
			// 
			// Statistic_label
			// 
			this->Statistic_label->Location = System::Drawing::Point(409, 187);
			this->Statistic_label->Name = L"Statistic_label";
			this->Statistic_label->Size = System::Drawing::Size(300, 436);
			this->Statistic_label->TabIndex = 8;
			this->Statistic_label->Text = L"";
			// 
			// Statistic_button
			// 
			this->Statistic_button->BackColor = System::Drawing::Color::Aquamarine;
			this->Statistic_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Statistic_button->Location = System::Drawing::Point(269, 549);
			this->Statistic_button->Name = L"Statistic_button";
			this->Statistic_button->Size = System::Drawing::Size(134, 73);
			this->Statistic_button->TabIndex = 9;
			this->Statistic_button->Text = L"����� ����������";
			this->Statistic_button->UseVisualStyleBackColor = false;
			this->Statistic_button->Click += gcnew System::EventHandler(this, &MyForm::Statistic_button_Click);
			// 
			// Delete_button
			// 
			this->Delete_button->BackColor = System::Drawing::Color::Red;
			this->Delete_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Delete_button->Location = System::Drawing::Point(716, 549);
			this->Delete_button->Name = L"Delete_button";
			this->Delete_button->Size = System::Drawing::Size(125, 73);
			this->Delete_button->TabIndex = 10;
			this->Delete_button->Text = L"��������� ����������";
			this->Delete_button->UseVisualStyleBackColor = false;
			this->Delete_button->Click += gcnew System::EventHandler(this, &MyForm::Delete_button_Click);
			// 
			// Find_text
			// 
			this->Find_text->Location = System::Drawing::Point(1019, 85);
			this->Find_text->Name = L"Find_text";
			this->Find_text->Size = System::Drawing::Size(257, 22);
			this->Find_text->TabIndex = 11;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(1028, 41);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(239, 29);
			this->label4->TabIndex = 12;
			this->label4->Text = L"����� �� ���������";
			// 
			// Find_button
			// 
			this->Find_button->BackColor = System::Drawing::Color::Aquamarine;
			this->Find_button->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->Find_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Find_button->Location = System::Drawing::Point(1062, 113);
			this->Find_button->Name = L"Find_button";
			this->Find_button->Size = System::Drawing::Size(171, 86);
			this->Find_button->TabIndex = 13;
			this->Find_button->Text = L"����� ���������� �� ���������";
			this->Find_button->UseVisualStyleBackColor = false;
			this->Find_button->Click += gcnew System::EventHandler(this, &MyForm::Find_button_Click);
			// 
			// No_sort_button
			// 
			this->No_sort_button->AutoSize = true;
			this->No_sort_button->Checked = true;
			this->No_sort_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->No_sort_button->Location = System::Drawing::Point(715, 362);
			this->No_sort_button->Name = L"No_sort_button";
			this->No_sort_button->Size = System::Drawing::Size(140, 22);
			this->No_sort_button->TabIndex = 14;
			this->No_sort_button->TabStop = true;
			this->No_sort_button->Text = L"��� ����������";
			this->No_sort_button->UseVisualStyleBackColor = true;
			this->No_sort_button->CheckedChanged += gcnew System::EventHandler(this, &MyForm::No_sort_button_CheckedChanged);
			// 
			// Buble_sort_button
			// 
			this->Buble_sort_button->AutoSize = true;
			this->Buble_sort_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Buble_sort_button->Location = System::Drawing::Point(715, 419);
			this->Buble_sort_button->Name = L"Buble_sort_button";
			this->Buble_sort_button->Size = System::Drawing::Size(208, 22);
			this->Buble_sort_button->TabIndex = 15;
			this->Buble_sort_button->Text = L"����������� ����������";
			this->Buble_sort_button->UseVisualStyleBackColor = true;
			this->Buble_sort_button->Click += gcnew System::EventHandler(this, &MyForm::Buble_sort_button_Click);
			// 
			// Quick_sort_button
			// 
			this->Quick_sort_button->AutoSize = true;
			this->Quick_sort_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Quick_sort_button->Location = System::Drawing::Point(715, 479);
			this->Quick_sort_button->Name = L"Quick_sort_button";
			this->Quick_sort_button->Size = System::Drawing::Size(174, 22);
			this->Quick_sort_button->TabIndex = 16;
			this->Quick_sort_button->Text = L"������� ����������";
			this->Quick_sort_button->UseVisualStyleBackColor = true;
			this->Quick_sort_button->Click += gcnew System::EventHandler(this, &MyForm::Quick_sort_button_Click);
			// 
			// Date_sort_button
			// 
			this->Date_sort_button->AutoSize = true;
			this->Date_sort_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Date_sort_button->Location = System::Drawing::Point(269, 433);
			this->Date_sort_button->Name = L"Date_sort_button";
			this->Date_sort_button->Size = System::Drawing::Size(86, 22);
			this->Date_sort_button->TabIndex = 18;
			this->Date_sort_button->Text = L"�� ����";
			this->Date_sort_button->UseVisualStyleBackColor = true;
			this->Date_sort_button->Click += gcnew System::EventHandler(this, &MyForm::Date_sort_button_Click);
			// 
			// Credits_sort_button
			// 
			this->Credits_sort_button->AutoSize = true;
			this->Credits_sort_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Credits_sort_button->Location = System::Drawing::Point(269, 486);
			this->Credits_sort_button->Name = L"Credits_sort_button";
			this->Credits_sort_button->Size = System::Drawing::Size(122, 22);
			this->Credits_sort_button->TabIndex = 19;
			this->Credits_sort_button->Text = L"�� ��������";
			this->Credits_sort_button->UseVisualStyleBackColor = true;
			this->Credits_sort_button->Click += gcnew System::EventHandler(this, &MyForm::Alf_sort_button_Click);
			// 
			// Graph
			// 
			chartArea1->Name = L"ChartArea1";
			this->Graph->ChartAreas->Add(chartArea1);
			legend1->Name = L"Legend1";
			this->Graph->Legends->Add(legend1);
			this->Graph->Location = System::Drawing::Point(919, 282);
			this->Graph->Name = L"Graph";
			series1->ChartArea = L"ChartArea1";
			series1->Legend = L"Legend1";
			series1->Name = L"Series1";
			this->Graph->Series->Add(series1);
			this->Graph->Size = System::Drawing::Size(494, 340);
			this->Graph->TabIndex = 20;
			this->Graph->Text = L"chart1";
			// 
			// Sort_type
			// 
			this->Sort_type->AutoSize = true;
			this->Sort_type->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Sort_type->Location = System::Drawing::Point(269, 362);
			this->Sort_type->Name = L"Sort_type";
			this->Sort_type->Size = System::Drawing::Size(124, 22);
			this->Sort_type->TabIndex = 21;
			this->Sort_type->Text = L"�� ��������";
			this->Sort_type->UseVisualStyleBackColor = true;
			this->Sort_type->Click += gcnew System::EventHandler(this, &MyForm::Sort_type_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(205, 307);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(181, 18);
			this->label5->TabIndex = 22;
			this->label5->Text = L"������� ����������:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label6->Location = System::Drawing::Point(715, 321);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(139, 18);
			this->label6->TabIndex = 23;
			this->label6->Text = L"��� ����������:";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label7->Location = System::Drawing::Point(460, 133);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(192, 36);
			this->label7->TabIndex = 24;
			this->label7->Text = L"����������";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label8->Location = System::Drawing::Point(1013, 234);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(290, 36);
			this->label8->TabIndex = 25;
			this->label8->Text = L"������ ��������";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::GradientInactiveCaption;
			this->ClientSize = System::Drawing::Size(1425, 625);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->Sort_type);
			this->Controls->Add(this->Graph);
			this->Controls->Add(this->Credits_sort_button);
			this->Controls->Add(this->Date_sort_button);
			this->Controls->Add(this->Quick_sort_button);
			this->Controls->Add(this->Buble_sort_button);
			this->Controls->Add(this->No_sort_button);
			this->Controls->Add(this->Find_button);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->Find_text);
			this->Controls->Add(this->Delete_button);
			this->Controls->Add(this->Statistic_button);
			this->Controls->Add(this->Statistic_label);
			this->Controls->Add(this->Error_label);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->Description);
			this->Controls->Add(this->Credits);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Category);
			this->Name = L"MyForm";
			this->Text = L"Expense counter";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Graph))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}

		int MonthArray(string* mass, int* days, int len, string elem) {
			int summ = 0;
			for (int i = 0; i < len; i++) {
				if (*(mass + i) == elem)
					return summ * 86400;
				summ += *(days + i);
			}
		}

		void qsortRecursive(int* mas, string* text_mas, int size) {
			int i = 0;
			int j = size - 1;

			int mid = mas[size / 2];

			do {
				
				while (mas[i] < mid) {
					i++;

				}
				while (mas[j] > mid) {
					j--;
				}

				if (i <= j) {
					swap(mas[i], mas[j]);
					swap(text_mas[i], text_mas[j]);

					i++;
					j--;
				}
			} while (i <= j);


			if (j > 0) {
				qsortRecursive(mas, text_mas, j + 1);
			}
			if (i < size) {
				qsortRecursive(&mas[i], &text_mas[i], size - i);
			}
		}


#pragma endregion
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {


			
			std::string str1 = msclr::interop::marshal_as<std::string>(this->Category->Text);
			std::string str2 = msclr::interop::marshal_as<std::string>(this->Credits->Text);
			std::string str3 = msclr::interop::marshal_as<std::string>(this->Description->Text);

			if (str1.find(":") == string::npos && str2.find(":") == string::npos && str3.find(":") == string::npos && str2 != "" && str1 != "") {

				int len_str2 = str2.size();

				int breaker = 1;

				for (int i = 0; i < len_str2; i++) {
					if (str2[i] < 48 || str2[i] > 57) {
						breaker = 0;
						break;
					}
				}

				if (breaker) {

					ofstream data_text("data.txt", ios_base::app);

					time_t now = time(0);

					char* dt = ctime(&now);


					data_text << str1 << ':' << str2 << ':' << str3 << ':' << dt;
					data_text << '\n';
					data_text.close();

					this->Error_label->Text = " ";
				}
				else 
					this->Error_label->Text = "������� ������ ���� ������!";

			}
			else
			this->Error_label->Text = "����������� ������!";
	}
	private: System::Void Statistic_button_Click(System::Object^ sender, System::EventArgs^ e) {

		this->Statistic_label->Text = "";

		string months[12]{ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
		int days[12]{ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

		
		

			ifstream data("data.txt");

			long long summa = 0;

			string text = "";
			string str;
			
			int j = 0;
			while (getline(data, str))
				j++;
			j /= 2;

			int* date_massive = new int[j];
			string* text_massive = new string[j];

			if (this->No_sort_button->Checked == true) {

				ifstream new_data3("data.txt");

				while (getline(new_data3, str)) {
					if (str != "") {
						text += '\n';
						text += "���������: " + str.substr(0, str.find(":")) + "   ";
						text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
						summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
						text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
						text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

						text += '\n';
					}
				}
			}
			else if (this->Buble_sort_button->Checked == true) {
				if (this->Date_sort_button->Checked == true) {

					

					string date_tmp;
					string month_tmp;
					int day_tmp;
					string time_tmp;
					int year_tmp;


					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {
							date_tmp = str.substr(str.find(" ") + 1, str.size() - str.find(" "));
							month_tmp = date_tmp.substr(0, date_tmp.find(" "));
							day_tmp = stoi(date_tmp.substr(date_tmp.find(" ") + 1, date_tmp.find(" ", date_tmp.find(" ") + 1) - date_tmp.find(" ")));
							time_tmp = date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ") + 1) + 1, date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) - date_tmp.find(" ", date_tmp.find(" ") + 1) - 1);
							year_tmp = stoi(date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) + 1, 4));



							date_massive[i] = stoi(time_tmp.substr(0, 2)) * 3600 + stoi(time_tmp.substr(3, 2)) * 60 + stoi(time_tmp.substr(6, 2)) + day_tmp * 86400 + MonthArray(months, days, 12, month_tmp) + (year_tmp - 2024) * 31536000;
							text_massive[i] = str;
							i++;
						}
					}

						for (int i = 0; i < j; i++) {
							for (int f = 0; f < j - 1; f++) {
								if (date_massive[f] > date_massive[f + 1]) {
									swap(date_massive[f], date_massive[f + 1]);
									swap(text_massive[f], text_massive[f + 1]);
								}
							}
						}

						if (this->Sort_type->Checked == true) {
							for (int i = 0; i < j / 2; i++)
								swap(text_massive[i], text_massive[j - i - 1]);
						}

						for (int i = 0; i < j; i++) {
							str = text_massive[i];
							if (str != "") {
								text += '\n';
								text += "���������: " + str.substr(0, str.find(":")) + "   ";
								text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
								summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
								text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
								text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

								text += '\n';
							}
						}
					
						

				}
				else {

					

					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {


							date_massive[i] = stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text_massive[i] = str;
							i++;
						}
					}

					for (int i = 0; i < j; i++) {
						for (int f = 0; f < j - 1; f++) {
							if (date_massive[f] > date_massive[f + 1]) {
								swap(date_massive[f], date_massive[f + 1]);
								swap(text_massive[f], text_massive[f + 1]);
							}
						}
					}

					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}

				}
			}
			else if (this->Quick_sort_button->Checked == true) {
				if (this->Date_sort_button->Checked == true) {
					

					string date_tmp;
					string month_tmp;
					int day_tmp;
					string time_tmp;
					int year_tmp;


					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {
							date_tmp = str.substr(str.find(" ") + 1, str.size() - str.find(" "));
							month_tmp = date_tmp.substr(0, date_tmp.find(" "));
							day_tmp = stoi(date_tmp.substr(date_tmp.find(" ") + 1, date_tmp.find(" ", date_tmp.find(" ") + 1) - date_tmp.find(" ")));
							time_tmp = date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ") + 1) + 1, date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) - date_tmp.find(" ", date_tmp.find(" ") + 1) - 1);
							year_tmp = stoi(date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) + 1, 4));



							date_massive[i] = stoi(time_tmp.substr(0, 2)) * 3600 + stoi(time_tmp.substr(3, 2)) * 60 + stoi(time_tmp.substr(6, 2)) + day_tmp * 86400 + MonthArray(months, days, 12, month_tmp) + (year_tmp - 2024) * 31536000;
							text_massive[i] = str;
							i++;
						}
					}

					qsortRecursive(date_massive, text_massive, j);

					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}
				}
				else {
					

					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {


							date_massive[i] = stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text_massive[i] = str;
							i++;
						}
					}

					qsortRecursive(date_massive, text_massive, j);

					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}
				}
			}

			text += '\n';

			text += "����� �����: " + to_string(summa) + '\n';

			time_t now = time(0);

			char* dt = ctime(&now);

			text += "The local date and time is: ";

			text += dt + '\n';



			this->Statistic_label->Text = gcnew System::String(text.c_str());

			ifstream new_data2("data.txt");
			int i = 0;
			int maxx = -999999999;
			while (getline(new_data2, str)) {
				if (str != "") {
					date_massive[i] = stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
					if (date_massive[i] > maxx)
						maxx = date_massive[i];
					i++;
				}
			}

			if (this->No_sort_button->Checked == false && j > 1) {
				Graphics^ g = Graph->CreateGraphics();
				g->Clear(System::Drawing::Color::White);  

				
				int width = Graph->Width;
				int height = Graph->Height;

				
				double scaleX = 0.1;  
				double scaleY = 0.8 * height / maxx;  

				double xMin = -18.0;
				double xMax = 50.0;
				double step = 0.1 * width / j;

				


				Pen^ graphPen = gcnew Pen(Color::Blue, 2);

				int cr_stat1;
				int cr_stat2;


				int i = 0;
				for (double x = xMin; x <= xMax; x += step)
				{
					cr_stat1 = stoi(text_massive[i].substr(text_massive[i].find(":") + 1, text_massive[i].find(":", text_massive[i].find(":") + 1) - text_massive[i].find(":")));
					cr_stat2 = stoi(text_massive[i + 1].substr(text_massive[i + 1].find(":") + 1, text_massive[i + 1].find(":", text_massive[i + 1].find(":") + 1) - text_massive[i + 1].find(":")));

					int screenX1 = (int)(width / 2 + x / scaleX);
					int screenY1 = (int)(height / 1.1 - cr_stat1 * scaleY);
					int screenX2 = (int)(width / 2 + (x + step) / scaleX);
					int screenY2 = (int)(height / 1.1 - cr_stat2 * scaleY);
					g->DrawLine(graphPen, screenX1, screenY1, screenX2, screenY2);
					i++;
					if (i == j - 1) {
						int screenX1 = (int)screenX2;
						int screenY1 = (int)screenY2;
						int screenX2 = (int)(width / 2 + (x + step) / scaleX);
						int screenY2 = (int)(height / 1.1 - (cr_stat2) * scaleY);
						g->DrawLine(graphPen, screenX1, screenY1, screenX2, screenY2);
						break;
					}
				}

				delete[] date_massive;
				delete[] text_massive;

			}
			
			

			

			
		

	}
private: System::Void Delete_button_Click(System::Object^ sender, System::EventArgs^ e) {
	ofstream data("data.txt", ios_base::out);
	data << "";
	this->Statistic_label->Text = "";
}
private: System::Void Find_button_Click(System::Object^ sender, System::EventArgs^ e) {
	Graphics^ g = Graph->CreateGraphics();
	g->Clear(System::Drawing::Color::White);
	this->Statistic_label->Text = "";
	if (this->Find_text->Text != "" && this->Find_text->Text != ":") {
		string months[12]{ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
		int days[12]{ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };




		ifstream data("data.txt");

		long long summa = 0;

		string text = "";
		string str;

		int j = 0;
		while (getline(data, str)) {
			if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {
				j++;
			}
		}

		if (j != 0) {



			int* date_massive = new int[j];
			string* text_massive = new string[j];

			if (this->No_sort_button->Checked == true) {

				ifstream new_data3("data.txt");

				while (getline(new_data3, str)) {
					if (str != "") {
						if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}
				}
			}
			else if (this->Buble_sort_button->Checked == true) {
				if (this->Date_sort_button->Checked == true) {



					string date_tmp;
					string month_tmp;
					int day_tmp;
					string time_tmp;
					int year_tmp;


					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {
							if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {
								date_tmp = str.substr(str.find(" ") + 1, str.size() - str.find(" "));
								month_tmp = date_tmp.substr(0, date_tmp.find(" "));
								day_tmp = stoi(date_tmp.substr(date_tmp.find(" ") + 1, date_tmp.find(" ", date_tmp.find(" ") + 1) - date_tmp.find(" ")));
								time_tmp = date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ") + 1) + 1, date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) - date_tmp.find(" ", date_tmp.find(" ") + 1) - 1);
								year_tmp = stoi(date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) + 1, 4));



								date_massive[i] = stoi(time_tmp.substr(0, 2)) * 3600 + stoi(time_tmp.substr(3, 2)) * 60 + stoi(time_tmp.substr(6, 2)) + day_tmp * 86400 + MonthArray(months, days, 12, month_tmp) + (year_tmp - 2024) * 31536000;
								text_massive[i] = str;
								i++;
							}
						}
					}

					for (int i = 0; i < j; i++) {
						for (int f = 0; f < j - 1; f++) {
							if (date_massive[f] > date_massive[f + 1]) {
								swap(date_massive[f], date_massive[f + 1]);
								swap(text_massive[f], text_massive[f + 1]);
							}
						}
					}

					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}



				}
				else {



					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {
							if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {


								date_massive[i] = stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
								text_massive[i] = str;
								i++;
							}
						}
					}

					for (int i = 0; i < j; i++) {
						for (int f = 0; f < j - 1; f++) {
							if (date_massive[f] > date_massive[f + 1]) {
								swap(date_massive[f], date_massive[f + 1]);
								swap(text_massive[f], text_massive[f + 1]);
							}
						}
					}


					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}

				}
			}
			else if (this->Quick_sort_button->Checked == true) {
				if (this->Date_sort_button->Checked == true) {


					string date_tmp;
					string month_tmp;
					int day_tmp;
					string time_tmp;
					int year_tmp;


					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {
							if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {
								date_tmp = str.substr(str.find(" ") + 1, str.size() - str.find(" "));
								month_tmp = date_tmp.substr(0, date_tmp.find(" "));
								day_tmp = stoi(date_tmp.substr(date_tmp.find(" ") + 1, date_tmp.find(" ", date_tmp.find(" ") + 1) - date_tmp.find(" ")));
								time_tmp = date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ") + 1) + 1, date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) - date_tmp.find(" ", date_tmp.find(" ") + 1) - 1);
								year_tmp = stoi(date_tmp.substr(date_tmp.find(" ", date_tmp.find(" ", date_tmp.find(" ") + 1) + 1) + 1, 4));



								date_massive[i] = stoi(time_tmp.substr(0, 2)) * 3600 + stoi(time_tmp.substr(3, 2)) * 60 + stoi(time_tmp.substr(6, 2)) + day_tmp * 86400 + MonthArray(months, days, 12, month_tmp) + (year_tmp - 2024) * 31536000;
								text_massive[i] = str;
								i++;
							}
						}
					}

					qsortRecursive(date_massive, text_massive, j);

					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}
				}
				else {


					ifstream new_data("data.txt");
					int i = 0;
					while (getline(new_data, str)) {
						if (str != "") {
							if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {


								date_massive[i] = stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
								text_massive[i] = str;
								i++;
							}
						}
					}

					qsortRecursive(date_massive, text_massive, j);

					if (this->Sort_type->Checked == true) {
						for (int i = 0; i < j / 2; i++)
							swap(text_massive[i], text_massive[j - i - 1]);
					}

					for (int i = 0; i < j; i++) {
						str = text_massive[i];
						if (str != "") {
							text += '\n';
							text += "���������: " + str.substr(0, str.find(":")) + "   ";
							text += "�������: " + str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")) + "   ";
							summa += stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
							text += "��������: " + str.substr(str.find(":", str.find(":") + 1) + 1, str.find(":", str.find(":", str.find(":") + 1) + 1) - str.find(":", str.find(":") + 1) - 1) + "   ";
							text += "����: " + str.substr(str.find(":", str.find(":", str.find(":") + 1) + 1) + 1, str.size() - str.find(":", str.find(":", str.find(":") + 1) + 1));

							text += '\n';
						}
					}
				}
			}

			text += '\n';

			text += "����� �����: " + to_string(summa) + '\n';

			time_t now = time(0);

			char* dt = ctime(&now);

			text += "The local date and time is: ";

			text += dt + '\n';



			this->Statistic_label->Text = gcnew System::String(text.c_str());

			ifstream new_data2("data.txt");
			int i = 0;
			int maxx = -999999999;
			while (getline(new_data2, str)) {
				if (str != "") {
					if (msclr::interop::marshal_as<std::string>(this->Find_text->Text) == str.substr(0, str.find(":"))) {

						date_massive[i] = stoi(str.substr(str.find(":") + 1, str.find(":", str.find(":") + 1) - str.find(":")));
						if (date_massive[i] > maxx)
							maxx = date_massive[i];
						i++;
					}
				}
			}

			if (this->No_sort_button->Checked == false && j > 1) {
		


				int width = Graph->Width;
				int height = Graph->Height;

				double scaleX = 0.1;
				double scaleY = 0.8 * height / maxx;

				double xMin = -18.0;
				double xMax = 50.0;
				double step = 0.1 * width / j;

				Pen^ graphPen = gcnew Pen(Color::Blue, 2);

				int cr_stat1;
				int cr_stat2;

				int i = 0;
				for (double x = xMin; x <= xMax; x += step)
				{
					cr_stat1 = stoi(text_massive[i].substr(text_massive[i].find(":") + 1, text_massive[i].find(":", text_massive[i].find(":") + 1) - text_massive[i].find(":")));
					cr_stat2 = stoi(text_massive[i + 1].substr(text_massive[i + 1].find(":") + 1, text_massive[i + 1].find(":", text_massive[i + 1].find(":") + 1) - text_massive[i + 1].find(":")));

					int screenX1 = (int)(width / 2 + x / scaleX);
					int screenY1 = (int)(height / 1.1 - cr_stat1 * scaleY);
					int screenX2 = (int)(width / 2 + (x + step) / scaleX);
					int screenY2 = (int)(height / 1.1 - cr_stat2 * scaleY);
					g->DrawLine(graphPen, screenX1, screenY1, screenX2, screenY2);
					i++;
					if (i == j - 1) {
						int screenX1 = (int)screenX2;
						int screenY1 = (int)screenY2;
						int screenX2 = (int)(width / 2 + (x + step) / scaleX);
						int screenY2 = (int)(height / 1.1 - (cr_stat2)*scaleY);
						g->DrawLine(graphPen, screenX1, screenY1, screenX2, screenY2);
						break;
					}
				}

				
			}

				delete[] date_massive;
				delete[] text_massive;
		}
	}
}


private: System::Void Date_sort_button_Click(System::Object^ sender, System::EventArgs^ e) {

	if (this->Credits_sort_button->Checked == true)
		this->Credits_sort_button->Checked = false;
	else
		this->Date_sort_button->Checked = true;
	if (this->No_sort_button->Checked == true)
		this->Date_sort_button->Checked = false;


	
}
private: System::Void Alf_sort_button_Click(System::Object^ sender, System::EventArgs^ e) {

	if (this->Date_sort_button->Checked == true) 
		this->Date_sort_button->Checked = false;
	else
		this->Credits_sort_button->Checked = true;
	if (this->No_sort_button->Checked == true)
		this->Credits_sort_button->Checked = false;

	
}
private: System::Void No_sort_button_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	if (this->No_sort_button->Checked == true) {
		this->Date_sort_button->Checked = false;
		this->Credits_sort_button->Checked = false;
		this->Sort_type->Checked = false;
	}

}
private: System::Void Credits_TextChanged(System::Object^ sender, System::EventArgs^ e) {

	
	std::string tmp = msclr::interop::marshal_as<std::string>(this->Credits->Text);

	

		if (tmp.size() > 9) {
			tmp = tmp.substr(0, tmp.size() - 1);
			this->Credits->Text = gcnew System::String(tmp.c_str());

		}

}

private: System::Void Buble_sort_button_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->No_sort_button->Checked == false && this->Date_sort_button->Checked == false && this->Credits_sort_button->Checked == false)
		this->Date_sort_button->Checked = true;
}
private: System::Void Quick_sort_button_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->No_sort_button->Checked == false && this->Date_sort_button->Checked == false && this->Credits_sort_button->Checked == false)
		this->Date_sort_button->Checked = true;
}


private: System::Void Sort_type_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->No_sort_button->Checked == true)
		this->Sort_type->Checked = false;
}
private: System::Void Category_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	std::string tmp = msclr::interop::marshal_as<std::string>(this->Category->Text);



	for (int i = 0; i < tmp.size(); i++) {
		if (tmp[i] == ':' || tmp[i] == ' ') {
			tmp = tmp.substr(0, i) + tmp.substr(i + 1, tmp.size() - i - 1);
			this->Category->Text = gcnew System::String(tmp.c_str());

		}
	}
}
private: System::Void Description_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	std::string tmp = msclr::interop::marshal_as<std::string>(this->Description->Text);



	for (int i = 0; i < tmp.size(); i++) {
		if (tmp[i] == ':' || tmp[i] == ' ') {
			tmp = tmp.substr(0, i) + tmp.substr(i + 1, tmp.size() - i - 1);
			this->Description->Text = gcnew System::String(tmp.c_str());

		}
	}
}
};
}
